ESP8266
=======
An Arduino library to manage the ESP8266. https://github.com/Diaoul/arduino-ESP8266

History
=======
0.1
---

* Initial version

About
=====
Author: Antoine Bertin

License: MIT

Code formated with: ``astyle --break-blocks --remove-brackets``
